# frozen_string_literal: true

class Example
  def hello
    'hello world'
  end
end
